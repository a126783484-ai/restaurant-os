
export const payments = {
  id: "serial primary key",
  orderId: "integer not null",
  paymentStatus: "varchar(50)",
  paymentMethod: "varchar(50)",
  subtotal: "numeric",
  discount: "numeric",
  serviceCharge: "numeric",
  actualPaid: "numeric",
  paymentTime: "timestamp"
};
