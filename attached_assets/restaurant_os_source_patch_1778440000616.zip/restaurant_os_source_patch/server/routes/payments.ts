
import express from "express";

const router = express.Router();

router.post("/", async (req, res) => {
  const {
    orderId,
    paymentMethod,
    subtotal,
    discount,
    serviceCharge,
    actualPaid
  } = req.body;

  const payment = {
    orderId,
    paymentStatus: "paid",
    paymentMethod,
    subtotal,
    discount,
    serviceCharge,
    actualPaid,
    paymentTime: new Date()
  };

  return res.json(payment);
});

router.get("/:id", async (req, res) => {
  return res.json({
    id: req.params.id,
    status: "paid"
  });
});

export default router;
